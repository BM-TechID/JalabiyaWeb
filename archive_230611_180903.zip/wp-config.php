<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'jalabiya' );

/** Database username */
define( 'DB_USER', 'jalabiya' );

/** Database password */
define( 'DB_PASSWORD', 'ittp04jalabiya' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'eFE=.LY$28$/=nG+P/D19m];g[N4W8R~ZO#JnBCDc~h9fsI7Y/]KcNX[/y $DeX}' );
define( 'SECURE_AUTH_KEY',  '9c 7M4vv.!7#NJIIaxQ8%c;[{q,rpMtW H9dzu=l(emr?<xe`wOfFZ<tH].uOSLJ' );
define( 'LOGGED_IN_KEY',    'D{&,IogpA{haiw2-%>-v/&LhO?~/U?^xj+xRJ5w /~~7H={kUuTo<^UM,*;Y9J}_' );
define( 'NONCE_KEY',        '2(`|U?X9=.k2G9Ywfs{r~t=-jX~]HK#o(04(fvV3-KJHsp9wU0Z<3}<:1v.T7HR6' );
define( 'AUTH_SALT',        '%Y@[}k9j`Hf`ro0L!@,m}x-~027S)||E~s/=hH01:gJnRUz+*p8 xM,30U^qMV,|' );
define( 'SECURE_AUTH_SALT', 'q^ q9=xly 1+XAvg z}jl-/Y_|s|?y;XHA1^:|4h3K_Sj,jsc(Pn-C+b+i_HN*so' );
define( 'LOGGED_IN_SALT',   '-q`Yv 9/CR6&JlUDm929qJJ}v;UOR#DK5}bJOx/cUC?)An~s/lN iaX[Qc;B6s1&' );
define( 'NONCE_SALT',       'x=9GF(Jjsxiy`>-=kc#l.8XjqaIzK~G3yW]k?+t<Ts}|jP3$TM~%5`>B_CL;_n6(' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_rental';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
